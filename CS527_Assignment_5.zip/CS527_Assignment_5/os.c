#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include "os.h"
#include "compiler.h"
#include "processor.h"
#include "memory.h"

// OS Queues and State
#define MAX_WAIT 100
char waiting_queue[MAX_WAIT][100];
int wait_head = 0, wait_tail = 0;

int proc_active[NP] = {0};
int proc_pid[NP] = {0};
int next_pid = 1;
int end_of_simulation = 0;

// Shell State
int shell_active = 1;
char shell_buffer[256];
int shell_idx = 0;

// NEW LAB 5 MMU Variables
char pageTable[MAX_PROC][NUM_LOGICAL_PAGES];
char freePages[NUM_PHYSICAL_PAGES] = {0};

// NEW LAB 5 MMU Functions
int getFreePage() {
    // Frame 0 is reserved, and will never be allocated[cite: 1]
    for (int i = 1; i < NUM_PHYSICAL_PAGES; i++) {
        if (freePages[i] == 0) {
            freePages[i] = 1; // Mark it allocated[cite: 1]
            return i;
        }
    }
    printf("\n[MMU Error] Out of physical memory frames!\n");
    exit(1); 
}

int getPhysicallAddress(int proc_id, int isFetch, int address) {
    // Index = (isFetch)? address / PAGESIZE: address /PAGESIZE + 1024/PAGESIZE[cite: 1]
    int index = (isFetch) ? (address / PAGESIZE) : (address / PAGESIZE + (1024 / PAGESIZE));
    
    // Access the page table to get physical page number[cite: 1]
    int phys_page = pageTable[proc_id][index];
    
    // Physical address = physical page number * PAGESIZE + address % PAGESIZE[cite: 1]
    return (phys_page * PAGESIZE) + (address % PAGESIZE);
}

void os_init() 
{
    FILE *log = fopen("execution.log", "w");
    if (log) fclose(log);
    printf("--- LAB 5 QUAD-CORE OS BOOTING ---\n");
    printf("$ ");
}

void loader(const char *filename) 
{
    int free_proc = -1;
    for (int i = 0; i < NP; i++) 
    {
        if (!proc_active[i]) { free_proc = i; break; }
    }

    if (free_proc != -1) 
    {
        int pid = next_pid++;
        
        char prog_byte[50];
        char data_byte[50];
        sprintf(prog_byte, "program_proc%d.byte", free_proc);
        sprintf(data_byte, "data_proc%d.byte", free_proc);

        compile(filename, prog_byte);
        
        FILE *d = fopen(data_byte, "a");
        if (d) fclose(d);

        reset_processor(free_proc);
        load_memory(free_proc, prog_byte, data_byte);
        
        // LAB 5 MMU INITIALIZE: Map Logical Buffers to Physical Frames
        
        // 1. Allocate 1 Page for Instructions (Logical Index 0)
        int inst_frame = getFreePage();
        pageTable[free_proc][0] = inst_frame;
        memcpy(&memory[inst_frame * PAGESIZE], Instruction[free_proc], 256);
        
        // 2. Allocate 8 Pages for Data (4096 bytes / 512 = 8 pages) (Logical Indices 2-9)
        for (int p = 0; p < 8; p++) {
            int data_frame = getFreePage();
            pageTable[free_proc][2 + p] = data_frame;
            memcpy(&memory[data_frame * PAGESIZE], &Data[free_proc][p * PAGESIZE], PAGESIZE);
        }

        printf("\n[OS Loader] Loaded '%s' into Processor %d (PID: %d)\n", filename, free_proc, pid);
        
        proc_pid[free_proc] = pid;
        proc_active[free_proc] = 1;
    } 
    else 
    {
        printf("\n[OS Loader] CPUs are full. '%s' added to Waiting Queue.\n", filename);
        strcpy(waiting_queue[wait_tail++], filename);
    }
}

void shell() {
    if (!shell_active) return;

    if (_kbhit()) 
    {
        char c = _getch();
        
        if (c == '\r' || c == '\n') {
            shell_buffer[shell_idx] = '\0';
            
            // CHANGED: Use strtok to split strings so you can run "test1.txt test2.txt"
            char *token = strtok(shell_buffer, " ");
            while (token != NULL) 
            {
                if (strcmp(token, "exit") == 0) 
                {
                    shell_active = 0;
                    printf("\n[OS Shell] Shutting down CLI. Finishing active tasks...\n");
                    break;
                } 
                else 
                {
                    loader(token);
                }
                token = strtok(NULL, " ");
            }
            
            if (shell_active) printf("\n$ ");
            shell_idx = 0;
            memset(shell_buffer, 0, sizeof(shell_buffer));
        } 
        else if (c == '\b') 
        { 
            if (shell_idx > 0) 
            {
                shell_idx--;
                printf("\b \b");
            }
        } 
        else 
        {
            shell_buffer[shell_idx++] = c;
            printf("%c", c);
        }
    }
}

void scheduler() {
    int any_active = 0;

    // all the processes, along with a shell process will keep getting a turn in round robin style[cite: 1]
    for (int i = 0; i < NP; i++) 
    {
        if (proc_active[i]) 
        {
            any_active = 1;
            
            // Run each task in the ready queue for fixed number of cycles[cite: 1]
            process_instructions(i, proc_pid[i], 10);
            
            if (core_halted[i]) 
            {
                printf("\n[OS Scheduler] Process %d on Processor %d finished!\n", proc_pid[i], i);
                
                // LAB 5 MMU FINALIZE: Map Physical memory back to Data array to save
                for (int p = 0; p < 8; p++) {
                    int data_frame = pageTable[i][2 + p];
                    if (data_frame != 0) {
                        memcpy(&Data[i][p * PAGESIZE], &memory[data_frame * PAGESIZE], PAGESIZE);
                    }
                }

                // Save out to unique file
                char outfile[50];
                sprintf(outfile, "data_out_proc%d.byte", i);
                save_memory(i, outfile);
                
                // Reset page table and free pages from freePage array[cite: 1]
                for (int p = 0; p < NUM_LOGICAL_PAGES; p++) {
                    int frame = pageTable[i][p];
                    if (frame != 0) {
                        freePages[frame] = 0;
                        pageTable[i][p] = 0;
                    }
                }
                
                proc_active[i] = 0;
                
                if (wait_head < wait_tail) 
                {
                    loader(waiting_queue[wait_head++]);
                } 
                else if (shell_active) 
                {
                    // CHANGED: Fixed the prompt glitch so it prints cleanly
                    printf("\n$ "); 
                }
            }
        }
    }
    
    if (!shell_active && !any_active && wait_head == wait_tail) 
    {
        end_of_simulation = 1;
    }
}

void os_run() 
{
    while (!end_of_simulation) 
    {
        scheduler();
        shell();
        Sleep(50);
    }
    printf("\n[OS] All processes complete. System shutting down safely.\n");
}