#include <stdio.h>
#include "memory.h"

char Instruction[256];
char Data[256];

void initialize() {
    FILE *prog_file = fopen("program.byte", "rb");
    if (prog_file) {
        fread(Instruction, 1, 256, prog_file);
        fclose(prog_file);
    }
    
    FILE *data_file = fopen("data.byte", "rb");
    if (data_file) {
        fread(Data, 1, 256, data_file);
        fclose(data_file);
    }
}

void finalize() {
    FILE *data_file = fopen("data.byte", "wb");
    if (data_file) {
        fwrite(Data, 1, 256, data_file);
        fclose(data_file);
    }
}