#include <stdio.h>
#include "compiler.h"

void compile() {
    int choice;
    char *filename = "";
    
    printf("Test programs:\n");
    printf("1 - Sum of N numbers\n");
    printf("2 - Multiply two complex numbers\n");
    printf("3 - Determinant of a 3x3 matrix\n");
    printf("Enter choice (1-3): ");
    
    scanf("%d", &choice);

    switch(choice) {
        case 1:
            filename = "faq1.txt";
            break;
        case 2:
            filename = "faq2.txt";
            break;
        case 3:
            filename = "faq3.txt";
            break;
        default:
            printf("Invalid choice.\n");
            return; 
    }

    FILE *txt_file = fopen(filename, "r");
    FILE *byte_file = fopen("program.byte", "wb");

    if (txt_file != NULL && byte_file != NULL) {
        int op, d, s1, s2;
        while (fscanf(txt_file, "%d %d %d %d", &op, &d, &s1, &s2) == 4) {
            char instr[4] = {(char)op, (char)d, (char)s1, (char)s2};
            fwrite(instr, 1, 4, byte_file);
        }
        fclose(txt_file);
        fclose(byte_file);
        printf("Compiled %s successfully.\n\n", filename);
    } else {
        printf("Error: Could not open %s\n", filename);
    }
}