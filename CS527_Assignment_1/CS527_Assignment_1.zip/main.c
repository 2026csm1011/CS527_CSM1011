#include <stdio.h>
#include "compiler.h"
#include "memory.h"
#include "processor.h"

int main() {
    compile();
    initialize();
    reset();
    
    while(end_of_simulation == 0) {
        fetch();
        decode();
        execute();
    }
    
    finalize();
    printf("\nSimulation complete. Check data.byte for memory outputs.\n");
    
    // This will print the final answers dynamically!
    printf("\n--- FINAL REGISTER STATES ---\n");
    for (int i = 0; i < 256; i++) {
        if (Register[i] != 0) {
            printf("Reg[%d] = %d\n", i, Register[i]);
        }
    }
    printf("-----------------------------\n");
    
    return 0;
}