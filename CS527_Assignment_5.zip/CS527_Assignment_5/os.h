#ifndef OS_H
#define OS_H

// Core OS Functions
void os_init();
void loader(const char *filename);
void scheduler();
void shell();
void os_run();

// Lab 5 MMU Functions
int getPhysicallAddress(int proc_id, int isFetch, int address);

#endif